package com.project.memory.exceptions;

public class MemoryAccessException extends Exception{
    public MemoryAccessException(String message) {
        super(message);
    }
}
