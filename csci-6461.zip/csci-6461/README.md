# User Guide
## GUI
### console
- if you type assmbly in console and click "Load" button, the instruction will be load into cpu and execute
- if cpu is waiting for input, please type in input and press "enter" on the keyboard

### Load
- load the instruction type in the console field to CPU and execute it

### Load+
- if manually change GPR, or other register except for PC, it will update to CPU

### Store, Store+
- not implement yet

### Halt
- halt the program

### Step
- set CPU PC to current PC show in the GUI (User update) and execute one instruction

### RUN
- Run the program that is loaded into memory

### IPL
- load the assembly file that user input in the Prgram File field to the Memory